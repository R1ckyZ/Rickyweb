    function qrCode() {
        var wx = window.setInterval(function () {
            //定时发送请求
            $.ajax({
                url: '/api/wx/check',
                type: 'post',
                dataType: 'json',
                data: {
                    "ticket": $("#wx").attr("value"),
                },
                success: function (data) {
                    var responseid = data.response;
                    if (responseid === 200) {
                        var session = "JSESSIONID = " + data.msg;
                        document.cookie = session;
                        console.log(session)
                        location.href = "/user";//解析ajax处理服务器端返回结果
                    }
                    if (responseid === 201) {
                        var session = "JSESSIONID = " + data.msg;
                        document.cookie = session;
                        location.href = "/api/wx/bind"
                    }
                },
                error: function (data) {
                    var responseid = data.response;
                    /*不做处理, 超时做处理再说*/
                }
            })
        }, 3000);
    }