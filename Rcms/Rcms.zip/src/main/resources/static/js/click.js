document.querySelector(".login-button").onclick = function () {
	submitForm();
}
		
function keyup_submit(e){		
         var evt = window.event || e;
         if (evt.keyCode === 13){
	submitForm();
         }
}