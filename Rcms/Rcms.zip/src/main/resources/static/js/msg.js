function AESencrypt(plaintText) {
        var key = CryptoJS.enc.Utf8.parse("R1ckymess4gesK3y");
        var encryptedData = CryptoJS.AES.encrypt(plaintText, key, {
            mode: CryptoJS.mode.ECB,
            padding: CryptoJS.pad.Pkcs7
        });
        return encryptedData.toString();
    }