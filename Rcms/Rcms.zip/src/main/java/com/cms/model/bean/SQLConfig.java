package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SQLConfig {
    private String sqlStr;
}
