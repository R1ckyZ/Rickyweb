package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Role {
    private int id;
    private String email;
    private Long role;
    private Integer settings;
    private Integer article;
    private Integer author;
    private Integer templates;
    private Integer vip;
}
