package com.cms.model.dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cms.model.bean.CommentView;

public interface CommentDAO extends BaseMapper<CommentView> {
}
