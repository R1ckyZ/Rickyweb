package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UrlInfo {
    private Integer option_id;
    private String option_field;
    private String option_name;
    private String option_value;
    private String autoload;
}
