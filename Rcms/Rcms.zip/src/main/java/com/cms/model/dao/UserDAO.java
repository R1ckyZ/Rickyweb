package com.cms.model.dao;

import com.cms.model.bean.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserDAO {

	// Ctrl+Shift+O，快捷导入所有import
	User find(@Param("email")String email, @Param("password")String password);

	User findMailUser(String email);

	String Mailfind(String email);

	int checkLogin(Integer id, String email);

	int checkAdminRole(String email);

	UserInfo findUser(String email);

	User findwxUser(String wxopenid);

	String haswxopenid(String email);

	UserInfo findUserById(int id);

	void addUser(@Param("password")String password, @Param("email")String email);

	void addwxUser(String password, String email, String wxopenid);

	void bindwxUser(String wxopenid, String email);

	void addUserinfo(String nickname, String avatar);

	void updateUser(String email, @Param("password")String password);

	void updateAdmininfo(String email, @Param("nickname")String nickname, @Param("avatar")String avatar, @Param("role")Long role, @Param("settings")Integer settings, @Param("article")Integer article, @Param("author")Integer author, @Param("templates")Integer templates);

	void resetUserinfo(String email, @Param("nickname")String nickname, @Param("avatar")String avatar);

	Role Roleset(String email);

	void updateUserproperty(String property, String value, String email);

	void updatePassword(String email, String password);

	void updateUserEmail(String property, String value, String email);

	List<Role> getUserList(int search_num, int limit_num);

	int getUserListNum();

	void DeleteUser(int id, String email);

	void DeleteUserInfo(int id);

	void updateUserRole(int id, String email, Long role, int settings, int article, int author, int templates, int vip);

	void updateUserAccount(int id, String email);

	String getUserEmail(int id);

	int getUserId(String wxopenid);
}
