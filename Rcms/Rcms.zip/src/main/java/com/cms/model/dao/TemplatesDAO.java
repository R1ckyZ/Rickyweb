package com.cms.model.dao;

import com.cms.model.bean.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface TemplatesDAO {
    List<TemplatesContent> gettemplates(Integer search_num, Integer limit_num);

    int gettemplatesnum();

    void AddTemplates(String name, String path, String type, String des);

    Integer FindTemplates(String filepath, String type);

    void DelTemplates(String filepath, String type);
}
