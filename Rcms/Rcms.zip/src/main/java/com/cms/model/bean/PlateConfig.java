package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PlateConfig {
    private String option_value;
}
