package com.cms.model.wx;

import org.springframework.stereotype.Component;
import weixin.popular.support.TokenManager;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * access_token管理
 */
@Component
public class TokenManagerListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        TokenManager.setDaemon(false);
        TokenManager.init("wxfc574025d4b31189","872b8a2155ba2e25031bfd588b6931f0");
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        TokenManager.destroyed();
    }
}
