package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MsgInfo {
    private int user_id;
    private String post_title;
    private String post_status;
    private String msg;
    private int view;
    private int id;
    private int post_id;
}
