package com.cms.model.util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import java.nio.charset.StandardCharsets;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AESUtil {
    static Logger logger = LoggerFactory.getLogger(AESUtil.class);

    /**
     * PKCS5Padding -- Pkcs7 两种padding方法都可以
     *
     * @param content hexString
     * @param key     R1ckymess4gesK3y
     * @return masget2019
     */
    public static String decryptAES(String content, String key) {
        try {
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES");
            // "算法/模式/补码方式"
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            //解密后是16进制
            return new String(cipher.doFinal(Objects.requireNonNull(parseHexStr2Byte(content))));
        } catch (Exception e) {
            logger.error(String.format("解密失败: content：%s, key: %s", content, key));
        }
        return content;
    }

    /**
     * 将16进制转换为二进制
     *
     * @param hexStr
     * @return
     */
    private static byte[] parseHexStr2Byte(String hexStr) {
        if (hexStr.length() < 1) {
            return null;
        }
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++) {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }
}
