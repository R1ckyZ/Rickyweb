package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**view*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArticleView {

    private Integer post_id;
    private String post_date;
    private String post_content = "temp";
    private String post_title = "temp";
    private String post_status = "temp";
    private String post_theme = "temp";
    private String post_label = "temp";
    private String post_url = "temp";
    private Integer read_times = 0;
    private String contact_method = "temp";
    private String author_contact = "temp";
    private String cover_pic = "/images/finding.jpg";
    private Integer is_up = 0;
    private Integer post_comment = 0;
    private String post_nickname;
    private String post_avatar;
    private String post_email;
    private Integer vip;
}
