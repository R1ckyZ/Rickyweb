package com.cms.model.util;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JDBCUtil {

    public static void release(ResultSet rs,Statement statement, Connection con) throws SQLException{

        try {
            if(rs != null)
                rs.close();
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        try {
            if(statement != null)
                statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(con != null)
                con.close();
        }
    }

    public static void release(Statement statement, Connection con) throws SQLException{
        try {
            if(statement != null)
                statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(con != null)
                con.close();
        }
    }
}

