package com.cms.model.dao;

import com.cms.model.bean.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Mapper
public interface UrlDAO {
    List<UrlDAO> Plateinfo();

    List<UrlDAO> Plateotherinfo();

    PlateConfig Getoption_value(Integer option_id);

    SQLConfig SQLversion();

    void updatePlateinfo(String option_value, Integer option_id);

    List<LinkedHashMap<String, Object>> superSelect(@Param("value") String value);
}
