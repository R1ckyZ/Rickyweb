package com.cms.model.bean;

import lombok.Data;
import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.util.List;

/**view*/
@Data
@TableName("rcms_comment_view")
public class CommentView {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer postId;
    private String content;
    private Integer parentId;
    private Date createTime;
    private String userNickname;
    private String userAvatar;
    private String replyTo;
    private Integer userId;
    private Integer isPost;

    @TableField(exist = false)
    private List<CommentView> commentList;
}
