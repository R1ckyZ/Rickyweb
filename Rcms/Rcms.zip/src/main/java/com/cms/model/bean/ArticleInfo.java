package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ArticleInfo {

    private Integer post_id;
    private Integer user_id;
    private String post_date;
    private String post_content = "temp";
    private String post_title = "temp";
    private String post_status = "temp";
    private String post_theme = "temp";
    private String post_label = "temp";
    private String post_url = "temp";
    private Integer read_times = 0;
    private String contact_method = "temp";
    private String author_contact = "temp";
    private Integer post_comment = 0;
    private String cover_pic = "/images/finding.jpg";
    private Integer is_up = 0;
}
