package com.cms.model.util;

//import com.alibaba.fastjson.JSONObject;
import com.cms.model.bean.MyException;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.boot.system.ApplicationHome;
import org.springframework.util.DigestUtils;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * @author: Ricky
 * @description:
 * @date: 2021/12/24 8:39
 */
@Slf4j
public class JwtUtil {
    /**自己设定的秘钥*/
    private static final String SECRET = "df292516cf7868c6f*b311094828a0e4cca2e94a92f6e2c4c39e741d0ace763c7";

    /**缓存路径*/
    private static String CachePath = null;
    private static final String CacheExt = ".json";

    static {
        try {
            CachePath = ResourceUtils.getURL("classpath:").getPath() + "public/cache/";
            File path = new File(ResourceUtils.getURL("classpath:").getPath(), "/public/cache");
            if (!path.exists()) {
                path.mkdirs();
            }
        } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
    }

    /**
     * 产生token
     * @param email 邮箱
     * @return token
     */
    public static String generateToken(String email){
        Date date = new Date();

        //构建json的filename
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String datetime = df.format(date);
        String filename = DigestUtils.md5DigestAsHex((email + "/" + datetime).getBytes());

        //构造过期时间,过期时间十分钟
        long term = System.currentTimeMillis() + 1000 * 60 * 10;

        String jwt = Jwts.builder()
                .claim("CacheFile",filename)
                //签发时间
                .setIssuedAt(new Date())
                //过期时间
                .setExpiration(new Date(term))
                .signWith(SignatureAlgorithm.HS256, SECRET)
                .compact();

        JsonBuilder(filename, email, df.format(new Date(term)), jwt);

        return jwt;
    }

    /**
     * Json Builder
     * @param filename
     * @param email
     * @param datetime
     * @param jwt
     */
    private static void JsonBuilder(String filename, String email, String datetime, String jwt){
        try {
            File jsonfile = new File(CachePath + filename + CacheExt);
            JSONObject json = new JSONObject();
            json.put("email",email);
            json.put("Date",datetime);
            json.put("JWT",jwt);
            if(jsonfile.createNewFile()) {
                BufferedWriter bw = new BufferedWriter(new FileWriter(jsonfile));
                bw.write(json.toString());
                bw.flush();
                bw.close();
            }
        } catch (Exception e){
            throw new MyException(500, "构建失败！");
        }
    }

    /**
     * 验证token
     * @param token token
     */
    public static String ValidateToken(String token) {
        try {
            // parse the token
            Claims claims = Jwts.parser()
                    .setSigningKey(SECRET)
                    .parseClaimsJws(token)
                    .getBody();
            //test
            return claims.get("CacheFile").toString();
        } catch (Exception e){
            if(ClearCache()) {
                throw new MyException(500, "校验失败！");
            }else{
                throw new MyException(500, "服务异常！");
            }
        }
    }

    /**
     * 从filename对应的json中获取用户名
     */
    public static String JsonInfo(String filename){
        try{
            File jwtfile = new File( CachePath + filename + CacheExt);
            BufferedReader br = new BufferedReader(new FileReader(jwtfile));
            // 只读取一行
            JSONObject cacheinfo = new JSONObject(br.readLine());
            String email = cacheinfo.getString("email");
            br.close();
            if(jwtfile.delete()) {
                return email;
            }else{
                return null;
            }
        } catch (Exception e){
//            throw new MyException(500, "解析失败！");
            return null;
        }
    }

    private static boolean ClearCache(){
        File cachedir = new File(CachePath);
        if (!cachedir.exists() || !cachedir.isDirectory()) {// 判断是否存在目录
            throw new MyException(500, "不存在此文件夹！");
        }
        String[] jsonfiles = cachedir.list();
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            for (int i = 0; i < Objects.requireNonNull(jsonfiles).length; i++) {
                File checkfile = new File(CachePath+jsonfiles[i]);
                BufferedReader br = new BufferedReader(new FileReader(checkfile));
                JSONObject cacheinfo = new JSONObject(br.readLine());
                Date date = df.parse(cacheinfo.getString("Date"));
                br.close();
                if(date.compareTo(new Date()) <= 0){
                    checkfile.delete();
                }
            }
            return true;
        } catch (Exception ignored){
            throw new MyException(500, "服务异常！");
        }
    }
}

