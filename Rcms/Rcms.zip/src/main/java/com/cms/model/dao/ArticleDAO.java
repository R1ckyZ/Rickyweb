package com.cms.model.dao;

import com.cms.model.bean.*;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface ArticleDAO {
    List<ArticleView> getArticle(int search_num, int limit_num);

    List<ArticleView> getoneArticle(int post_id);

    List<ArticleView> getoneViewArticle(int post_id);

    List<ArticleView> getArticlefilterbytheme(String post_theme, int search_num, int limit_num);

    List<ArticleView> getRandomArticle(int num);

    List<ArticleView> getArticlefilterbysearch(String things, int search_num, int limit_num);

    List<ArticleView> findArticle(String post_email);

    Integer NumOfUserArticle(String author);

    @Options(useGeneratedKeys = true, keyProperty = "article.post_id") // post_id自动增长
    void InsertNewArticle(ArticleInfo article);

    void AddNewArticle(int post_id, String post_date, String post_content, String post_title, String post_status, String post_theme, String post_label, String post_url, String contact_method, String author_contact);

    void AddReadTime(int post_id);

    void AddCommentTime(int post_id);

    List<ThemeList> getThemeList();

    Integer getThemeAritcleNum(String post_theme);

    List<ArticleView> getThemeAritcle(String post_theme, Integer search_num, Integer limit_num);

    void UpdateArticle(int post_id, String post_theme, String post_title, String post_label, String post_status, int is_up, String cover_pic);

    void RejectArticle(int post_id, String post_status);

    void DeleteArticle(int post_id);

    void SendArticleMsg(int post_id, String msg);

    List<MsgInfo> getMsgInfo(int user_id);

    void signMsgView(int id, int user_id);

    List<ArticleInfo> DraftInfo(int user_id);

    String DraftView(int post_id, int user_id);

    void DraftDel(int post_id, int user_id);
}
