package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Status {
    private Integer response;
    private Integer status;
    private String msg;
}
