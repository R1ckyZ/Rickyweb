package com.cms.model.wx;

import com.cms.model.bean.MyException;
import com.cms.model.bean.UserInfo;
import com.cms.model.dao.UserDAO;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.util.ResourceUtils;
import weixin.popular.bean.xmlmessage.XMLMessage;
import weixin.popular.bean.xmlmessage.XMLTextMessage;
import weixin.popular.support.ExpireKey;
import weixin.popular.support.expirekey.DefaultExpireKey;
import javax.servlet.ServletOutputStream;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class WeChatAction {
    private static ExpireKey expireKey = new DefaultExpireKey();

    /**
     * 缓存路径
     */
    private static String CachePath = null;
    private static final String CacheExt = ".json";

    @Autowired
    private UserDAO userDAO;

    private final Logger logger = LoggerFactory.getLogger(getClass());

    /**
     * 创建默认的cache目录
     */
    static {
        try{
            CachePath = ResourceUtils.getURL("classpath:").getPath() + "public/wechat/cache/";
            File path = new File(ResourceUtils.getURL("classpath:").getPath() + "public/wechat/cache");
            if(!path.exists()){
                path.mkdirs();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void scanAction(Map<String,String> wxdata, ServletOutputStream outputStream){
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//注意月和小时的格式为两个大写字母
        Date date = new Date();//获得当前时间
        String login_date = df.format(date);//将当前时间转换成特定格式的时间字符串，这样便可以插入到数据库中
        Integer id = userDAO.getUserId(wxdata.get("FromUserName"));
        UserInfo user = userDAO.findUserById(id);
        wxReplyMsg(wxdata,outputStream,String.format("【AmTrain信息安全漏洞资讯平台】 尊敬的用户，您的账号（邮箱:%s，昵称:%s）于%s登录。若非本人操作，请及时更改账号密码。",
                user.getEmail(), user.getNickname(), login_date));
        logger.info("关注用户ID："+id);
        if(id == null){
            //没有在数据库中查询到wxopenid对应的用户
        }else{
            //在数据库中查询到了wxopenid对应的用户
            wxJsonBuilder(wxdata,id);
        }
    }

    protected void subscribeAction(Map<String,String> wxdata, ServletOutputStream outputStream){
        wxReplyMsg(wxdata,outputStream,"感谢您的关注");
        wxJsonBuilder(wxdata);
    }

    private void wxReplyMsg(Map<String,String> wxdata, ServletOutputStream outputStream, String msg){
        String key = wxdata.get("FromUserName")+ "__"
                + wxdata.get("ToUserName")+ "__"
                + wxdata.get("MsgId") + "__"
                + wxdata.get("CreateTime");

        //重复通知检测
        if(expireKey.exists(key)){
            //重复通知
            return;
        }else{
            //第一次通知
            expireKey.add(key);
        }

        //创建回复
        XMLMessage xmlTextMessage = new XMLTextMessage(
                wxdata.get("FromUserName"),
                wxdata.get("ToUserName"), msg);
        //回复
        xmlTextMessage.outputStreamWrite(outputStream);
    }

    /**
     * scanAction调用的方法,调用的时候id不应为空
     * @param wxdata
     * @param id
     */
    private void wxJsonBuilder(Map<String,String> wxdata,Integer id){
        try{
            File jsonfile = new File(CachePath +
                    DigestUtils.md5DigestAsHex(wxdata.get("Ticket").getBytes()) +
                    CacheExt);
            jsonfile.setWritable(true, false);
            JSONObject json = new JSONObject();
            json.put("id",id);
            json.put("time",wxdata.get("CreateTime"));
            if(jsonfile.createNewFile()){
                BufferedWriter bw = new BufferedWriter(new FileWriter(jsonfile));
                bw.write(json.toString());
                bw.flush();
                bw.close();
            }
        } catch (Exception e) {
            logger.error("调用失败！");
//            System.out.println("wxJsonBuilder IOException");
        }
    }

    /**
     * subscribeAction调用的方法,无id
     * @param wxdata
     */
    private void wxJsonBuilder(Map<String,String> wxdata){
        try{
            File jsonfile = new File(CachePath +
                    DigestUtils.md5DigestAsHex(wxdata.get("Ticket").getBytes()) +
                    CacheExt);
            jsonfile.setWritable(true, false);
            JSONObject json = new JSONObject();
            json.put("time",wxdata.get("CreateTime"));
            json.put("wxopenid",wxdata.get("FromUserName"));
            if(jsonfile.createNewFile()){
                BufferedWriter bw = new BufferedWriter(new FileWriter(jsonfile));
                bw.write(json.toString());
                bw.flush();
                bw.close();
            }
        } catch (Exception e) {
            logger.error("调用失败！");
        }
    }

    protected List<Integer> wxJsonCheck(String ticket, long postTime){
        Integer id = null;
        List<Integer> list = new ArrayList<>();
        list.add(0,null);
        try{
            File jsonfile = new File(CachePath + DigestUtils.md5DigestAsHex(ticket.getBytes()) + CacheExt);
            BufferedReader br = new BufferedReader(new FileReader(jsonfile));
            JSONObject cacheinfo = new JSONObject(br.readLine());
            br.close();
            if(cacheinfo.has("id")){
                id = cacheinfo.getInt("id");
                list.add(1,1);
            }else{
                //0表示没有json中没有id属性
                list.add(1,0);
                return list;
            }
            Long createTime = Long.parseLong(cacheinfo.getString("time")) * 1000L;
            if((postTime-createTime)>5000L){
                return list;
            }
        } catch(Exception e){
            return null;
        }
        list.set(0,id);
        return list;
    }

    protected String getWXOpenId(String ticket){
        try {
            File jsonfile = new File(CachePath + DigestUtils.md5DigestAsHex(ticket.getBytes()) + CacheExt);
            BufferedReader br = new BufferedReader(new FileReader(jsonfile));
            JSONObject cacheinfo = new JSONObject(br.readLine());
            String wxopenid = cacheinfo.getString("wxopenid");
            br.close();
            jsonfile.delete();
            return wxopenid;
        }catch(Exception e){
            throw new MyException(500,"读取失败");
        }
    }
}
