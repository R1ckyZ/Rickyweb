package com.cms.model.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Date {
    private String year;
    private String month;
    private String day;
}
