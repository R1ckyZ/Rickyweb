package com.cms.controller;

import com.cms.model.bean.ArticleView;
import com.cms.model.bean.MsgInfo;
import com.cms.model.dao.ArticleDAO;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@Api(tags = "IndexController")
public class IndexController {

    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;
    @Autowired
    private ArticleDAO articleDAO;

    @GetMapping(value = {"","index"})
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "Rcms主页",response = IndexController.class)
    })
    public Object index(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        if(session.getAttribute("userid") != null){
            int user_id = (int) session.getAttribute("userid");
            List<MsgInfo> msginfo = articleDAO.getMsgInfo(user_id);
            int msgcount = msginfo.size();
            model.addAttribute("msgcount", msgcount);
        }
        session.setAttribute("more", 1);
        session.removeAttribute("theme");
        session.removeAttribute("search");
        List<ArticleView> articleDAOList = articleDAO.getArticle(0, 6);
        model.addAttribute("userinfo", userDAO.findUser(email));
        model.addAttribute("email", email);
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        model.addAttribute("siteurl", urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("logo", urlDAO.Getoption_value(6));
        model.addAttribute("articlelist", articleDAOList);
        return new ModelAndView("index"); // 此处指向界面
    }

    @GetMapping(value = {"more"})
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "Rcms主页",response = IndexController.class)
    })
    public Object index_refresh(Model model, HttpSession session){
        String theme = session.getAttribute("theme") == null? "default" : (String) session.getAttribute("theme");
        String things = session.getAttribute("search") == null? "default" : (String) session.getAttribute("search");
        int more = (int) session.getAttribute("more") + 1;
        session.setAttribute("more", more);
        if(theme.equals("default") && things.equals("default")) {
            List<ArticleView> articleDAOList = articleDAO.getArticle(0, more * 6);
            model.addAttribute("articlelist", articleDAOList);
        }else if(!theme.equals("default") && things.equals("default")){
            List<ArticleView> articleDAOList = articleDAO.getArticlefilterbytheme(theme, 0, more * 6);
            model.addAttribute("articlelist", articleDAOList);
        }else if(theme.equals("default") && !things.equals("default")){
            List<ArticleView> articleDAOList = articleDAO.getArticlefilterbysearch(things, 0, more * 6);
            int articlecount = articleDAOList.size();
            model.addAttribute("search", 1);
            model.addAttribute("articlelist", articleDAOList);
            model.addAttribute("articlecount", articlecount);
        }
        return "index::table_refresh"; // 此处指向界面
    }
}
