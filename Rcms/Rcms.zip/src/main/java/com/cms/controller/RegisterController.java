package com.cms.controller;

import com.cms.model.bean.Status;
import com.cms.model.bean.User;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@RestController
@Api(tags = "RegisterController")
public class RegisterController {

    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;

    @GetMapping(value = "register")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "用户注册页面", response = UserController.class)
    })
    public Object register(Model model) {
        if(urlDAO.Getoption_value(4).getOption_value().equals("1")) {
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("siteurl", urlDAO.Getoption_value(1));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            model.addAttribute("logo", urlDAO.Getoption_value(6));
            return new ModelAndView("register"); // 此处指向界面
        } else {
            return "<script language=\"javascript\">\n" +
                    "alert(\"注册页面已关闭！\");\n" +
                    "window.location.href=\"user\";\n" +
                    "</script>";
        }
    }

    @PostMapping(value = "register")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "email", value = "字符型", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "password", value = "字符型", paramType = "query", dataType = "String"),
            @ApiImplicitParam(name = "repassword", value = "字符型", paramType = "query", dataType = "String")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "用户注册成功", response = UserController.class)
    })
    @ResponseBody
    public Object UserRegister(String password, String repassword, String email, @RequestParam(required = false) String m, HttpSession session, HttpServletResponse response) {
        if(urlDAO.Getoption_value(4).getOption_value().equals("1")) {
            if (StringUtils.isEmpty(email) || StringUtils.isEmpty(password)) {
                response.setStatus(500);
                return new Status(500, 26, "用户名或密码不能为空！");
            } else if(StringUtils.isEmpty(repassword) || !password.equals(repassword)) {
                response.setStatus(500);
                return new Status(500, 25, "请再次输入相同的密码！");
            } else {
                String wxopenid = (String) session.getAttribute("wxopenid");
                User emailuser = userDAO.findMailUser(email);
                if(wxopenid != null){
                    User wxuser = userDAO.findwxUser(wxopenid);
                    if(wxuser == null && emailuser == null){
                        userDAO.addwxUser(password, email, wxopenid);
                        userDAO.addUserinfo(email,"/images/user.jpg");
                    }else if (wxuser == null & emailuser != null){
                        User existuser = userDAO.find(email, password);
                        if(existuser == null){
                            response.setStatus(500);
                            return new Status(500, 33, "绑定用户的邮箱或密码错误！");
                        }else if(!userDAO.haswxopenid(email).equals("")){
                            response.setStatus(500);
                            return new Status(500, 33, "该用户已绑定微信号！");
                        }
                        userDAO.bindwxUser(wxopenid, email);
                        session.setAttribute("userid", emailuser.getId());
                        session.setAttribute("email", email);
                        return new Status(200, 43, "绑定成功！");
                    }
                }else {
                    String femail = userDAO.Mailfind(email);
                    if (femail != null && femail.equals(email)) {
                        response.setStatus(500);
                        return new Status(500, 27, "该邮箱已绑定！");
                    }
                    userDAO.addUser(password, email);
                    userDAO.addUserinfo(email, "/images/user.jpg");
                }
                User user = userDAO.find(email, password);
                if (user != null) {
                    return new Status(200, 28, "注册成功！");
                } else{
                    response.setStatus(500);
                    return new Status(500, 29, "注册失败！");
                }
            }
    }else{
            return new ModelAndView("register");
        }
    }
}