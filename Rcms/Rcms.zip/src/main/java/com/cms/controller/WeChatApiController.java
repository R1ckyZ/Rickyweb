package com.cms.controller;

import com.alibaba.fastjson.JSONObject;
import com.cms.model.bean.MyException;
import com.cms.model.bean.Status;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import com.cms.model.wx.WeChatAction;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import weixin.popular.support.TokenManager;
import weixin.popular.util.SignatureUtil;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 微信消息接收层
 * 扫描二维码返回示例:{Ticket=gQEn8DwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyOFhEZjh0Tm5kTkUxWlQyNXh4Y3EAAgQfwMVhAwRYAgAA, CreateTime=1640350297, EventKey=, Event=SCAN, ToUserName=gh_0a4fa92d4986, FromUserName=osRdx6H9n4iD8JCgyhxGk_gW_fNY, MsgType=event}
 * 关注公众号返回示例:{CreateTime=1640350332, EventKey=, Event=subscribe, ToUserName=gh_0a4fa92d4986, FromUserName=osRdx6H9n4iD8JCgyhxGk_gW_fNY, MsgType=event}
 * 取关公众号返回示例:{CreateTime=1640350309, EventKey=, Event=unsubscribe, ToUserName=gh_0a4fa92d4986, FromUserName=osRdx6H9n4iD8JCgyhxGk_gW_fNY, MsgType=event}
 * @author 凋斓
 */
@Controller
public class WeChatApiController extends WeChatAction {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private UrlDAO urlDAO;

    @Autowired
    private UserDAO userDAO;

    private final Logger logger = LoggerFactory.getLogger(getClass());

//    /**
//     * 获取带参数的图片
//     * @return
//     */
//    @GetMapping("/wxlogin")
//    public Object getToken(Model model){
//        String real_get_ticket_url = String.format("https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=%s"
//                ,TokenManager.getToken("wx28c270268c95cfc3"));
//        JSONObject json_request = new JSONObject();
//        json_request.put("action_name","QR_STR_SCENE");
//        json_request.put("expire_seconds","600");
//        json_request.put("action_info",new JSONObject().put("scene",new JSONObject().put("scene_id",1)));
//        JSONObject json_ticket = restTemplate.postForObject(real_get_ticket_url,json_request,JSONObject.class);
//        model.addAttribute("real_get_image_url",String.format("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=%s",
//                json_ticket.getString("ticket")));
//        model.addAttribute("ticket",json_ticket.getString("ticket"));
//        System.out.println(json_ticket.getString("ticket"));
//        return "user::table_refresh";
//    }

    /**
     * 微信推送事件url
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping("/api/wx")
    @ResponseBody
    public void getTicket(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ServletOutputStream outputStream = response.getOutputStream();
        request.setCharacterEncoding("UTF-8");
        String signature = request.getParameter("signature");
        String timestamp = request.getParameter("timestamp");
        String nonce = request.getParameter("nonce");
        String echostr = request.getParameter("echostr");

//        System.out.println(signature);
//        System.out.println(timestamp);
//        System.out.println(nonce);

        /**
         * 首次请求申请验证,返回echostr
         */
        if(echostr!=null){
            outputStreamWrite(outputStream,echostr);
            return;
        }

        /**
         * 请求验证签名
         * 如果签名异常,直接退出
         */
        //微信开发者设置的token
        String TOKEN = urlDAO.Getoption_value(10).getOption_value();
        if(!signature.equals(SignatureUtil.generateEventMessageSignature(TOKEN,timestamp,nonce))){
//            System.out.println("The request signature is invalid");
            return;
        }

        Map<String, String> wxdata = parseXml(request);
        if(wxdata.get("MsgType")!=null){
            if("event".equals(wxdata.get("MsgType"))){
                //用户第一次关注
                logger.info("是否关注："+wxdata.get("Event"));
//                System.out.println(wxdata.get("Event"));
                if("subscribe".equals(wxdata.get("Event"))){
                    subscribeAction(wxdata,outputStream);
                }
                //用户扫描二维码
                if("SCAN".equals(wxdata.get("Event"))){
                    scanAction(wxdata,outputStream);
                }
            }
        }
        return;
    }

    /**
     * 前端校验接口
     * @param ticket
     * @param session
     * @param response
     * @return
     */
    @PostMapping("/api/wx/check")
    @ResponseBody
    public Object wxCacheCheck(String ticket, HttpSession session,HttpServletResponse response){
        long postTime = new Date().getTime();
        List<Integer> list = wxJsonCheck(ticket,postTime);
        //json中有id字段
        if(list == null) {
            //没有找到对应的json
            response.setStatus(500);
            return new Status(500, 20, "wxcheck验证失败");
        }

        if(list.get(1)==1){
            //找到了对应的json
            session.setAttribute("userid",list.get(0));
            session.setAttribute("email",userDAO.getUserEmail(list.get(0)));
            session.setMaxInactiveInterval(20*60);
            String sessionId = session.getId();
            return new Status(200,20,sessionId);
        }
        //json中没有id字段,进入绑定用户
        if(list.get(1)==0){
            String wxopenid = getWXOpenId(ticket);
            if(wxopenid == null){
                throw new MyException(500,"读取失败");
            }
            session.setAttribute("wxopenid",wxopenid);
            String sessionId = session.getId();
            return new Status(201,20,sessionId);
        }
        return null;
    }

    @GetMapping("/api/wx/bind")
    public Object wxBindUser(HttpSession session, Model model){
        String wxopenid = (String) session.getAttribute("wxopenid");
        if(wxopenid == null){
            return "redirect:/login";
        }
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        model.addAttribute("siteurl", urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("logo", urlDAO.Getoption_value(6));
        return new ModelAndView("bind");
    }

    /**
     * dom4j 解析 xml 转换为 map
     * @param request
     * @return
     * @throws Exception
     */
    private static Map<String, String> parseXml(HttpServletRequest request) throws Exception {
        // 将解析结果存储在HashMap中
        Map<String, String> map = new HashMap<String, String>();
        // 从request中取得输入流
        InputStream inputStream = request.getInputStream();
        // 读取输入流
        SAXReader reader = new SAXReader();
        Document document = reader.read(inputStream);
        // 得到xml根元素
        Element root = document.getRootElement();
        // 得到根元素的所有子节点
        List<Element> elementList = root.elements();

        // 遍历所有子节点
        for (Element e : elementList)
            map.put(e.getName(), e.getText());

        // 释放资源
        inputStream.close();
        return map;
    }

    /**
     * 数据流输出
     * @param outputStream
     * @param text
     * @return
     */
    private static boolean outputStreamWrite(OutputStream outputStream, String text){
        try {
            outputStream.write(text.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
