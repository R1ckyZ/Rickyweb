package com.cms.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.cms.model.bean.*;
import com.cms.model.dao.ArticleDAO;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import com.cms.service.CommentService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Date;

@RestController
@RequestMapping("comment")
public class CommentController extends CheckController {

    @Autowired
    CommentService commentService;
    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;
    @Autowired
    private ArticleDAO articleDAO;

    @PostMapping("/add")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "添加评论", response = UserController.class)
    })
    public Object add(@RequestBody CommentView comment, HttpSession session, HttpServletResponse response) {
        if (checkUser(session)) {
            // 判断内容是否全
            if (StringUtils.isEmpty(comment.getContent())) {
                response.setStatus(500);
                return new Status(500, 35, "评论内容不能为空！");
            }
            int post_id = (int) session.getAttribute("post_id");
            int user_id = (int) session.getAttribute("userid");
            comment.setUserId(user_id);
            comment.setPostId(post_id);
            comment.setCreateTime(new Date());
            if (Integer.parseInt(urlDAO.Getoption_value(9).getOption_value()) == 1) {
                comment.setIsPost(0);
            } else {
                comment.setIsPost(1);
            }
            commentService.save(comment);
            articleDAO.AddCommentTime(post_id);
            return new Status(200, 36, "发表评论成功！");
        } else {
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping("/remove/{id}")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "删除评论", response = UserController.class)
    })
    public Object remove(HttpSession session, @PathVariable Integer id) {
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if (checkAdmin(session) && roleselect.getArticle().equals(1)) {
            // 先删除子回复
            QueryWrapper queryWrapper = new QueryWrapper();
            queryWrapper.eq("parent_id", id);
            commentService.remove(queryWrapper);
            // 删除父级回复
            commentService.removeById(id);

            return new Status(200, 38, "删除评论成功！");
        } else {
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping("/modify/{id}")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "修改评论", response = UserController.class)
    })
    public Object modify(HttpSession session, @PathVariable Integer id, String content, int is_post) {
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if (checkAdmin(session) && roleselect.getArticle().equals(1)) {
            // 更新当前id回复
            CommentView commentView = new CommentView();
            commentView.setContent(content);
            commentView.setIsPost(is_post);
            UpdateWrapper<CommentView> updateWrapper = new UpdateWrapper<>();
            updateWrapper.eq("id", id);
            commentService.update(commentView, updateWrapper);

            return new Status(200, 32, "修改评论成功！");
        } else {
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }
}
