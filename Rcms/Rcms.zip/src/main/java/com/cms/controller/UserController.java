package com.cms.controller;

import com.alibaba.fastjson.JSONObject;
import com.cms.model.bean.*;
import com.cms.model.dao.ArticleDAO;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import com.cms.model.util.AESUtil;
import com.cms.model.util.JwtUtil;
import com.cms.service.MailService;
import io.swagger.annotations.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import weixin.popular.support.TokenManager;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

//@RestController = @Controller + @ResponseBody
@Controller
@Api(tags = "UserController")
public class UserController extends CheckController {

    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;
    @Autowired
    private ArticleDAO articleDAO;
    @Autowired
    private MailService mailService;

    private final String TOKEN="diaolanya";

    @GetMapping(value = "user")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "用户平台跳转",response = UserController.class)
    })
    public Object user(Model model, HttpSession session){
        if(checkUser(session)) {
            int user_id = (int) session.getAttribute("userid");
            return "redirect:/member/" + user_id;
        }else {
            return "redirect:/login";
        }
    }

    @GetMapping(value = "login")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "用户登录跳转",response = UserController.class)
    })
    public Object login(Model model, HttpSession session){
        if(checkUser(session)){
            return "redirect:/user";
        }else {
            String real_get_ticket_url = String.format("https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=%s"
                    , TokenManager.getToken("wxfc574025d4b31189"));
            JSONObject json_request = new JSONObject();
            json_request.put("action_name", "QR_STR_SCENE");
            json_request.put("expire_seconds", "180");
            json_request.put("action_info", new JSONObject().put("scene", new JSONObject().put("scene_id", 1)));
            JSONObject json_ticket = restTemplate.postForObject(real_get_ticket_url, json_request, JSONObject.class);
            model.addAttribute("real_get_image_url", String.format("https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=%s",
                    json_ticket.getString("ticket")));
            model.addAttribute("ticket", json_ticket.getString("ticket"));
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("siteurl", urlDAO.Getoption_value(1));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            model.addAttribute("logo", urlDAO.Getoption_value(6));
            return new ModelAndView("user"); // 此处指向界面
        }
    }

    @PostMapping(value = "login")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "email",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "password",value = "字符型",paramType = "query",dataType = "String")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "用户登录成功",response = UserController.class)
    })
    @ResponseBody
    public Object UserLogin(Model model, String email, String password, HttpSession session, HttpServletResponse response) {
        if (StringUtils.isEmpty(email) || StringUtils.isEmpty(password)) {
            response.setStatus(500);
            return new Status(500, 31, "用户名或密码不能为空！");
        }
        password = AESUtil.decryptAES(password, "R1ckymess4gesK3y");
        assert password != null;
        User user = userDAO.find(email, DigestUtils.md5DigestAsHex(password.getBytes()));
        if (user != null && user.getId().equals(1)) {
            response.setStatus(500);
            return new Status(500, 33, "用户名或密码错误！");
        }
        if (user != null) {
            session.setAttribute("userid", user.getId());
            session.setAttribute("email", user.getEmail());
            session.setMaxInactiveInterval(60 * 20); //单位秒
            return new Status(200, 30, "登录成功，正在进入个人主页...");
        } else {
            response.setStatus(500);
            return new Status(500, 33, "用户名或密码错误！");
        }
    }

    @PostMapping(value = "user/save")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "property",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "value",value = "字符型",paramType = "query",dataType = "String")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "保存成功",response = UserController.class)
    })
    @ResponseBody
    public Object save_value(String property, String value, HttpSession session, HttpServletResponse response){
        if(checkUser(session)) {
            String email = (String) session.getAttribute("email");
            switch (property){
                case "avatar":
                    userDAO.updateUserproperty("avatar", value, email);
                    break;
                case "nickname":
                    userDAO.updateUserproperty("nickname", value, email);
                    break;
                case "email":
                    if(Pattern.compile(email_regx).matcher(value).find() && !userDAO.findUser(email).getEmail().equals(value)) {
                        userDAO.updateUserproperty("email", value, email);
                        userDAO.updateUserEmail("email", value, email);
                        break;
                    }else{
                        response.setStatus(500);
                        return new Status(500, 18, "错误参数或邮箱已被绑定！");
                    }
                case "sex":
                    userDAO.updateUserproperty("sex", value, email);
                    break;
                default:
                    response.setStatus(500);
                    return new Status(500, 18, "错误参数！");
            }
            return new Status(200, 17, "保存成功！");
        }else {
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @GetMapping(value = "forget")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "找回密码", response = UserController.class)
    })
    public Object forget_password(Model model){
        //test
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        model.addAttribute("siteurl", urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("logo", urlDAO.Getoption_value(6));
        return new ModelAndView("forget");
    }

    @PostMapping(value = "forget")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "找回密码",response = UserController.class)
    })
    @ResponseBody
    public Object find_password(String email, HttpServletRequest request, HttpServletResponse response){
        String femail = userDAO.Mailfind(email);
        if(femail != null && femail.equals(email)) {
            String token = JwtUtil.generateToken(email);
//        System.out.println(token);
            //向邮箱发送邮件
            mailService.sendMimeMail(email, request.getRequestURL().toString().replace("forget", "reset") + "?token=" + token);
            return new Status(200, 22, "邮件发送成功，请到邮箱中查看。");
        }else{
            response.setStatus(500);
            return new Status(500, 34, "未找到此邮箱！");
        }
    }

    @GetMapping(value = "reset")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "修改密码页面",response = UserController.class)
    })
    public Object reset_password(Model model, String token, HttpSession session){
        String cachefile = JwtUtil.ValidateToken(token);
        if(cachefile != null){
            session.setAttribute("cachefile", cachefile);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("siteurl", urlDAO.Getoption_value(1));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            model.addAttribute("logo", urlDAO.Getoption_value(6));
            return new ModelAndView("reset");
        }else{
            throw new MyException(500, "校验已过期:(");
        }
    }

    @PostMapping(value = "reset")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "修改密码成功",response = UserController.class)
    })
    @ResponseBody
    public Object change_password(String password, String repassword, HttpSession session, HttpServletResponse response){
        if (StringUtils.isEmpty(password) || StringUtils.isEmpty(repassword)) {
            response.setStatus(500);
            return new Status(500, 24, "密码不能为空！");
        } else if(!password.equals(repassword)) {
            response.setStatus(500);
            return new Status(500, 25, "请再次输入相同的密码！");
        }
        String cachefile = session.getAttribute("cachefile").toString();
        if(cachefile != null){
            String email = JwtUtil.JsonInfo(cachefile);
            if(email != null){
                userDAO.updatePassword(email, password);
                return new Status(200, 23, "密码修改成功！");
            }else{
                response.setStatus(500);
                return new Status(500, 27, "校验已过期！");
            }
        }else{
            return new Status(500, 27, "校验已过期！");
        }
    }


    @GetMapping(value = "logout")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "用户注销",response = UserController.class)
    })
    public String logout(HttpSession session){
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping(value = "user/post")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "转到稿件页面",response = UserController.class)
    })
    public Object edit_page(Model model, HttpSession session){
        if(checkUser(session)) {
            String email = (String) session.getAttribute("email");
            UserInfo user = userDAO.findUser(email);
            int user_id = (int) session.getAttribute("userid");
            List<MsgInfo> msginfo = articleDAO.getMsgInfo(user_id);
            int msgcount = msginfo.size();

            model.addAttribute("msginfo", msginfo);
            model.addAttribute("msgcount", msgcount);
            model.addAttribute("email", email);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("siteurl", urlDAO.Getoption_value(1));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            model.addAttribute("logo", urlDAO.Getoption_value(6));
            model.addAttribute("userinfo", user);
            return new ModelAndView("user/post");
        } else {
            return "redirect:/";
        }
    }

    @PostMapping(value = "user/post")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "稿件存储成功",response = ModelController.class)
    })
    @ResponseBody
    public Object page_post(HttpSession session, HttpServletRequest request, HttpServletResponse response, String title, String theme, String label, String method, String calllabel, String content, String post_status){
        if(checkUser(session)) {
            int id = (int) session.getAttribute("userid");
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//注意月和小时的格式为两个大写字母
            Date date = new Date();//获得当前时间
            String post_date = df.format(date);//将当前时间转换成特定格式的时间字符串，这样便可以插入到数据库中
            String year = String.format("%tY", date);
            String month = String .format("%tm", date);
            String day = String .format("%td", date);
            ArticleInfo articleinfo = new ArticleInfo();
            int post_id;
            String post_url;
            if(!title.equals("") && !theme.equals("") && !label.equals("") && !method.equals("") && !calllabel.equals("") && !content.equals("")){
                switch (post_status){
                    case "reviewing":
                        articleinfo.setUser_id(id);
                        articleinfo.setPost_date(post_date);
                        this.articleDAO.InsertNewArticle(articleinfo);
                        post_id = articleinfo.getPost_id();
                        post_url = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + "/read/" + year + "/" + month + "/" + day + "/" + post_id;
                        // 一般不会开启
                        if(Integer.parseInt(urlDAO.Getoption_value(8).getOption_value()) == 0){
                            post_status = "publish";
                        }
                        if(content.startsWith("<!--markdown-->")) {
                            articleDAO.AddNewArticle(post_id, post_date, content, title, post_status, theme, label, post_url, method, calllabel);
                        }else{
                            Document htmlcontent = Jsoup.parse(content);
                            articleDAO.AddNewArticle(post_id, post_date, htmlcontent.toString(), title, post_status, theme, label, post_url, method, calllabel);
                        }
                        return new Status(200, 19, "投稿成功");
                    case "save":
                        articleinfo.setUser_id(id);
                        articleinfo.setPost_date(post_date);
                        this.articleDAO.InsertNewArticle(articleinfo);
                        post_id = articleinfo.getPost_id();
                        post_url = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort() + "/read/" + year + "/" + month + "/" + day + "/" + post_id;
                        if(content.startsWith("<!--markdown-->")) {
                            articleDAO.AddNewArticle(post_id, post_date, content, title, post_status, theme, label, post_url, method, calllabel);
                        }else{
                            Document htmlcontent = Jsoup.parse(content);
                            articleDAO.AddNewArticle(post_id, post_date, htmlcontent.toString(), title, post_status, theme, label, post_url, method, calllabel);
                        }
                        return new Status(200, 20, "保存草稿成功");
                    default:
                        response.setStatus(500);
                        return new Status(500, 21, "参数异常");
                }
            } else{
                response.setStatus(500);
                return new Status(500, 21, "留有空白将视为无效稿件！");
            }
        }else {
            return "redirect:/";
        }
    }

    @GetMapping(value = "member/{id}")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "用户预览页面",response = UserController.class)
    })
    public Object user_view(Model model, HttpSession session, @PathVariable int id) {
        try {
            UserInfo user = userDAO.findUserById(id);
            List<ArticleView> article = articleDAO.findArticle(user.getEmail());
            String email = (String) session.getAttribute("email");
            int user_id = session.getAttribute("userid") == null ? 0 : (int) session.getAttribute("userid");
            model.addAttribute("email", email);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("siteurl", urlDAO.Getoption_value(1));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            model.addAttribute("logo", urlDAO.Getoption_value(6));
            model.addAttribute("userinfo", userDAO.findUserById(user_id));
            model.addAttribute("otheruserinfo", user);
            model.addAttribute("articleinfo", article);
            model.addAttribute("articlenum", articleDAO.NumOfUserArticle(user.getEmail()));
            List<MsgInfo> msginfo = articleDAO.getMsgInfo(user_id);
            List<ArticleInfo> draftinfo = articleDAO.DraftInfo(user_id);
            int msgcount = msginfo.size();
            int deaftcount = draftinfo.size();
            model.addAttribute("msginfo", msginfo);
            model.addAttribute("msgcount", msgcount);
            model.addAttribute("draftinfo", draftinfo);
            model.addAttribute("draftcount", deaftcount);
            if (user_id == user.getId()) {
                return new ModelAndView("user/index");
            } else {
                model.addAttribute("userid", user_id);
                return new ModelAndView("user/info");
            }
        }catch (Exception ignored){
            return "redirect:/login";
        }
    }

    @PostMapping(value = "msg/{id}")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "标记已读",response = UserController.class)
    })
    @ResponseBody
    public Object msg_view(HttpSession session, @PathVariable int id) {
        if(checkUser(session)) {
            int user_id = (int) session.getAttribute("userid");
            articleDAO.signMsgView(id, user_id);
            return new Status(200, 41, "标记已读");
        } else {
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "/draft/{id}")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "草稿内容",response = UserController.class)
    })
    @ResponseBody
    public Object draft_view(HttpSession session, @PathVariable int id, @RequestParam(required = false) String m) {
        if(checkUser(session)) {
            int user_id = (int) session.getAttribute("userid");
            if(m != null && m.equals("delete")){
                articleDAO.DraftDel(id, user_id);
                return new Status(200, 43, "稿件已完全删除！");
            }
            String draftcontent = articleDAO.DraftView(id, user_id);
            return new Status(200, 42, draftcontent);
        } else {
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }
}


