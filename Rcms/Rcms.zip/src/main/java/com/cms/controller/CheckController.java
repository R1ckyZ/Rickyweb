package com.cms.controller;

import com.cms.model.bean.AdminUser;
import com.cms.model.bean.CheckLogin;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.http.HttpSession;

abstract class CheckController {

    @Autowired
    private UserDAO userDAO;

    public final String email_regx = "^[_a-z0-9-]+(\\.[_a-z0-9-]+)*@[a-z0-9-]+(\\.[a-z0-9-]+)*(\\.[a-z]{2,})$";

    boolean checkUser(HttpSession session){
        String email = (String) session.getAttribute("email");
        Integer userid = (Integer) session.getAttribute("userid");
        int check = userDAO.checkLogin(userid, email);
        return check == 1;
    }

    // role 角色权限需添加
    boolean checkAdmin(HttpSession session){
        String email = (String) session.getAttribute("email");
        Integer userid = (Integer) session.getAttribute("userid");
        int check = userDAO.checkLogin(userid, email);
        int admincheck = userDAO.checkAdminRole(email);
        return check == 1 && admincheck == 1;
    }

    Long checkRole(Integer settings, Integer article, Integer author, Integer templates){
        Long role = 0L;
        if(settings == 1){role++;}
        if(article == 1){role++;}
        if(author == 1){role++;}
        if(templates == 1){role++;}
        return role;
    }
}
