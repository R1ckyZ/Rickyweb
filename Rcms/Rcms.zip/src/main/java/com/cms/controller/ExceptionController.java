package com.cms.controller;

import com.cms.model.bean.MyException;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestControllerAdvice
public class ExceptionController {

    // 捕获全局异常
    @ExceptionHandler(value = Exception.class)
    Object handleException(Model model, Exception e, HttpServletRequest request) {
        model.addAttribute("code", "Error 100");
        model.addAttribute("msg", e.getMessage());
//        model.addAttribute("url", request.getRequestURL());
        return new ModelAndView("error/error");
    }

    // Myexception类
    @ExceptionHandler(value = MyException.class)
    Object handleMyException(Model model, MyException e, HttpServletRequest request) {

        model.addAttribute("msg", e.getMsg());
        model.addAttribute("code", "Error "+e.getCode());
//        model.addAttribute("url", request.getRequestURL());  // api接口获取
        return new ModelAndView("error/error");
    }
}