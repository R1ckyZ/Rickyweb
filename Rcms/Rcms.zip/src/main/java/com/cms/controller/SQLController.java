package com.cms.controller;

import ch.qos.logback.core.util.FileUtil;
import com.cms.model.bean.*;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.Data;
import net.sf.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.system.ApplicationHome;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Data
@Controller
@RequestMapping(value = "admin")
@Api(tags = "SQLController")
public class SQLController extends CheckController {
    @Value("${spring.datasource.username}")
    private String userName;
    @Value("${spring.datasource.password}")
    private String password;
    @Value("${spring.datasource.url}")
    private String url;

    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;

    private final String jdbc_regex = "[\"jdbc:mysql:\"]+\\W\\W([a-zA-Z0-9\\.]{1,})\\W([\\d+]{1,5})\\W([a-zA-Z0-9\\_]{1,})\\?";

    @PostMapping(value = "data")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "数据库操作",response = AdminController.class)
    })
    @ResponseBody
    private Object sql_control(Model model, HttpSession session, HttpServletResponse response, String m, @RequestParam(required = false) String db_format,@RequestParam(required = false) String filename){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getRole().equals(4L)) {
            // windows
            ApplicationHome home = new ApplicationHome(getClass());
            File jarFile = home.getSource();
            String PATH = jarFile.getParentFile().getPath();
            File backupDir = new File(PATH, "/public/backup");
            if (!backupDir.exists()) {// 如果目录不存在
                backupDir.mkdirs();// 创建文件夹
            }
            switch (m){
                case "backup":
                    try {
                        String backupPath = (String) backup(PATH);
                        if(backupPath != null) {
                            return new Status(200, 38, "数据备份成功，存储在" + backupPath + "下。");
                        }else{
                            return new Status(200, 38, "数据备份失败！");
                        }
                    } catch (Exception ignored){
                        return new Status(500, 21, "参数异常");
                    }
                case "source":
                    try{
                        String data = "";
                        int count = 1;
                        File[] fileList = backupDir.listFiles();
                        for(File file:fileList){
                            data = data + "{\"id\":\"" + count + "\",\"filename\":\"" + file.getName() + "\"},";
                            count ++;
                        }
                        count = count - 1;
                        data = "{\"code\":0,\"msg\":\"success\",\"count\":" + count + ",\"data\":[" + data.substring(0, data.length() - 1) + "]}";
                        return data;
                    }catch (Exception ignored){
                        return new Status(500, 21, "暂未发现备份文件！");
                    }
                case "import":
                    try{
                        if(recover(PATH, filename)){
                            return new Status(200, 38, "数据导入成功。");
                        }
                    }catch (Exception ignored){
                        return new Status(500, 21, "参数异常");
                    }
                case "execute":
                default:
                    response.setStatus(500);
                    return new Status(500, 21, "参数异常");
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    public Object backup(String PATH) throws FileNotFoundException  {
        DateFormat df = new SimpleDateFormat("yyyy.MM.dd_HH.mm.ss");
        String fileName = "rcms_" + df.format(new Date()) + ".sql";
        String hostIP = null;
        String hostPort = null;
        String databaseName = null;
        try {
            Pattern pattern = Pattern.compile(jdbc_regex);
            Matcher matcher = pattern.matcher(url);
            if (matcher.find()) {
                hostIP = matcher.group(1);
                hostPort = matcher.group(2);
                databaseName = matcher.group(3);
            }
            String backupPath = PATH + "/public/backup/";
            StringBuilder cmd = new StringBuilder()
                    .append("mysqldump ")
                    .append("--column-statistics=0") /**新版本mysqldump需要添加此元素而旧版本不需要,根据需求修改*/
//                    .append("--no-tablespaces ")
                    .append(" -h")
                    .append(hostIP)
                    .append(" -P")
                    .append(hostPort)
                    .append(" -u")
                    .append(userName)
                    .append(" -p")
                    .append(password)
                    // 如果需要排除某张备份表，把这个空格注释掉
                    .append(" ")
                    // 排除MySQL备份表
                    // .append(" --ignore-table ")
                    // .append(database_name)
                    // .append(".mysql_backups")
                    .append(databaseName)
                    .append(" > ")
                    .append(backupPath)
                    .append(fileName);
            String osName = System.getProperty("os.name").toLowerCase();
            String[] command = new String[0];
            if (osName.startsWith("windows")) {
                // Windows
                command = new String[]{"cmd", "/c", String.valueOf(cmd)};
            } else if (osName.startsWith("linux")){
                // Linux
                command = new String[]{"/bin/sh", "-c", String.valueOf(cmd)};
            }
            Process process = Runtime.getRuntime().exec(command);
            if(process.waitFor() == 0){
                return backupPath + fileName;
            }
            return null;
        }catch (Exception e) {
            throw new MyException(500, "服务异常！");
        }
    }

    public boolean recover(String PATH, String savePath) {
        String hostIP = null;
        String hostPort = null;
        String databaseName = null;
        try {
            savePath = PATH + "/public/backup/" + savePath;
            Pattern pattern = Pattern.compile(jdbc_regex);
            Matcher matcher = pattern.matcher(url);
            if (matcher.find()) {
                hostIP = matcher.group(1);
                hostPort = matcher.group(2);
                databaseName = matcher.group(3);
            }
            StringBuilder cmd = new StringBuilder()
                    .append("mysql -h")
                    .append(hostIP)
                    .append(" -P")
                    .append(hostPort)
                    .append(" -u")
                    .append(userName)
                    .append(" -p")
                    .append(password)
                    .append(" ")
                    .append(databaseName)
                    .append(" < ")
                    .append(savePath);
            String osName = System.getProperty("os.name").toLowerCase();
            String[] command = new String[0];
            if (osName.startsWith("windows")) {
                // Windows
                command = new String[]{"cmd", "/c", String.valueOf(cmd)};
            } else if (osName.startsWith("linux")){
                // Linux
                command = new String[]{"/bin/sh", "-c", String.valueOf(cmd)};
            }
            Process process = Runtime.getRuntime().exec(command);
            return process.waitFor() == 0;
        }catch (Exception e) {
            throw new MyException(500, "服务异常！");
        }
    }

    @PostMapping(value = "sql")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "sql语句执行",response = AdminController.class)
    })
    @ResponseBody
    private Object sql_jdbc(HttpSession session, String sql) throws SQLException {
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getRole().equals(4L)) {
            try {
                List<LinkedHashMap<String, Object>> entityList = urlDAO.superSelect(sql);
                JSONArray json = JSONArray.fromObject(entityList);
                return new Status(200, 39, json.toString());
            } catch (Exception e) {
                throw new MyException(500, "服务异常！");
            }
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }
}
