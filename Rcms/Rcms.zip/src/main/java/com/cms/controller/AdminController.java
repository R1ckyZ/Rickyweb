package com.cms.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cms.model.bean.*;
import com.cms.model.dao.ArticleDAO;
import com.cms.model.dao.TemplatesDAO;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import com.cms.model.util.AESUtil;
import com.cms.service.CommentService;
import io.swagger.annotations.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.regex.Pattern;

@Controller
@RequestMapping(value = "admin")
@Api(tags = "AdminController")
public class AdminController extends CheckController{

    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;
    @Autowired
    private TemplatesDAO templatesDAO;
    @Autowired
    private ArticleDAO articleDAO;
    @Autowired
    CommentService commentService;

    Logger logger = LoggerFactory.getLogger(getClass());
    public final String Author = "胡雪岩，刘鹏，丁茜";
    public final String MaxUpload = "10M";
    public final String CMSversion = "1.0.0";

    @GetMapping(value = "")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "后台跳转",response = AdminController.class)
    })
    private Object admin(Model model, HttpSession session){
        model.addAttribute("siteurl",urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        if(checkAdmin(session)) {
            String email = (String) session.getAttribute("email");
            UserInfo user = userDAO.findUser(email);
            Role roleselect = userDAO.Roleset(email);
            SQLConfig sqlversion = urlDAO.SQLversion();
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("cmsversion", CMSversion);
            model.addAttribute("author", Author);
            model.addAttribute("jdk", System.getProperty("java.version"));
            model.addAttribute("sqlversion", sqlversion);
            model.addAttribute("MaxUpload", MaxUpload);
            return new ModelAndView("admin/index"); // 此处指向界面
        }else {
            return "admin"; // 此处指向界面
        }
    }

    @PostMapping(value = "")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "email",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "password",value = "字符型",paramType = "query",dataType = "String")
    })
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "超级管理员登录成功",response = AdminController.class)
    })
    @ResponseBody
    private Object AdminLogin(String email, String password, HttpSession session, HttpServletResponse response) {
        if (StringUtils.isEmpty(email) || StringUtils.isEmpty(password)) {
            response.setStatus(500);
            return new Status(500, 31, "邮箱或密码不能为空！");
        }
        password = AESUtil.decryptAES(password, "R1ckymess4gesK3y");
        User user = userDAO.find(email, DigestUtils.md5DigestAsHex(password.getBytes()));
        int admincheck = userDAO.checkAdminRole(email);
        if (user != null && (user.getId().equals(1)||admincheck == 1)) {
            // 跳转后台页面
            session.setAttribute("userid", user.getId());
            session.setAttribute("email", user.getEmail());
            session.setMaxInactiveInterval(60 * 20); //单位秒
            return new Status(200, 30, "登录成功，正在进入个人主页...");
        }
        if (user != null) {
            response.setStatus(500);
            return new Status(500, 32, "只允许管理员在此登录！");
        } else {
            response.setStatus(500);
            return new Status(500, 33, "用户名或密码错误！");
        }
    }

    @GetMapping(value = "role")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "权限设置",response = AdminController.class)
    })
    @ResponseBody
    private Object role(HttpSession session){
        if(checkAdmin(session)) {
            String email = (String) session.getAttribute("email");
            return userDAO.Roleset(email);
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @GetMapping(value = "info")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "管理员信息",response = AdminController.class)
    })
    private Object admininfo(Model model, HttpSession session){
        if(checkAdmin(session)) {
            String email = (String) session.getAttribute("email");
            UserInfo user = userDAO.findUser(email);
            int admincheck = userDAO.checkAdminRole(email);
            Role roleselect = userDAO.Roleset(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("admininfo", admincheck);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/info"); // 此处指向界面
        }else {
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @PostMapping(value = "edit", produces = "application/json;charset=utf-8")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "nickname",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "avatar",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "password",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "newpassword",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "renewpassword",value = "字符型",paramType = "query",dataType = "String"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "修改成功",response = AdminController.class)
    })
    @ResponseBody
    private Object adminedit(String nickname, String avatar, String password, String newpassword, String renewpassword, Integer settings, Integer article, Integer author, Integer templates, HttpSession session){
        if(checkAdmin(session)) {
            String email = (String) session.getAttribute("email");
            Integer userid = (Integer) session.getAttribute("userid");
            if(userid.equals(1)) {
                Long role = checkRole(settings, article, author, templates);
                userDAO.updateAdmininfo(email, nickname, avatar, role, settings, article, author, templates);
            }else{
                userDAO.resetUserinfo(email, nickname, avatar);
            }
            if(!password.equals("") && !newpassword.equals("") && !renewpassword.equals("")){
                password = AESUtil.decryptAES(password, "A4dm1nC0nf1gk3ys");
                User newuser = userDAO.find(email, DigestUtils.md5DigestAsHex(password.getBytes()));
                if(newuser != null && newpassword.equals(renewpassword) && !password.equals(newpassword)){
                    newpassword = AESUtil.decryptAES(newpassword, "A4dm1nC0nf1gk3ys");
                    userDAO.updateUser(email, DigestUtils.md5DigestAsHex(newpassword.getBytes()));
                    return new Status(200, 1, "基本信息和密码修改成功！"); // 返回数据
                }else{
                    return new Status(200, 2, "原密码输入有误或与新密码重复！"); // 返回数据
                }
            }
            return new Status(200, 1, "基本信息修改成功！"); // 返回数据
        }else {
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @PostMapping(value = "reset")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "nickname",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "avatar",value = "字符型",paramType = "query",dataType = "String"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "重置成功",response = AdminController.class)
    })
    @ResponseBody
    private Object reset(String nickname, String avatar, HttpSession session){
        if(checkAdmin(session)) {
            String email = (String) session.getAttribute("email");
            userDAO.resetUserinfo(email, nickname, avatar);
            return new Status(200, 1, "基本信息重置成功！"); // 返回数据
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "options")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "系统配置",response = AdminController.class)
    })
    private Object options(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getSettings().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            List<UrlDAO> options = urlDAO.Plateinfo();
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("optionlists", options);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/settings"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @PostMapping(value = "options", produces = "application/json;charset=utf-8")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "siteurl",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "title",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "admin_email",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "user_can_register",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "allow_upload",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "logo",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "copy_right",value = "字符型",paramType = "query",dataType = "String"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "系统配置修改成功",response = AdminController.class)
    })
    @ResponseBody
    private Object option_modify(String siteurl, String title, String admin_email, String user_can_register, String allow_upload, String logo, String copy_right, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getSettings().equals(1)) {
            if(!siteurl.equals("") && !title.equals("") && Pattern.compile(email_regx).matcher(admin_email).find() && !user_can_register.equals("") && !allow_upload.equals("") && !logo.equals("") && !copy_right.equals("")) {
                String[] options = {siteurl, title, admin_email, user_can_register, allow_upload, logo, copy_right};
                int i = 1;
                for (String op : options) {
                    urlDAO.updatePlateinfo(op, i);
                    i++;
                }
                return new Status(200, 7, "系统配置修改成功！"); // 返回数据
            }else{
                return new Status(200, 8, "系统配置内容不能为空！"); // 返回数据
            }
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "others")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "其它设置",response = AdminController.class)
    })
    private Object others(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getSettings().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            List<UrlDAO> options = urlDAO.Plateotherinfo();
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("optionlists", options);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/others"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @PostMapping(value = "others", produces = "application/json;charset=utf-8")
    @ApiOperation(value = "POST")
    @ApiImplicitParams(value = {
            @ApiImplicitParam(name = "check_post",value = "字符型",paramType = "query",dataType = "String"),
            @ApiImplicitParam(name = "check_meta",value = "字符型",paramType = "query",dataType = "String"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "系统配置修改成功",response = AdminController.class)
    })
    @ResponseBody
    private Object others_modify(String check_post, String check_meta, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getSettings().equals(1)) {
            if(!check_post.equals("") && !check_meta.equals("")) {
                String[] options = {check_post, check_meta};
                int i = 8;
                for (String op : options) {
                    urlDAO.updatePlateinfo(op, i);
                    i++;
                }
                return new Status(200, 9, "其它配置修改成功！"); // 返回数据
            }else{
                return new Status(200, 10, "其它配置内容不能为空！"); // 返回数据
            }
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "templates")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "模板列表",response = AdminController.class)
    })
    private Object templates_list(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getTemplates().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/templates"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "new")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "新增模板",response = AdminController.class)
    })
    private Object new_templates(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getTemplates().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/templates_add"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "theme")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "分类管理",response = AdminController.class)
    })
    private Object theme_view(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getArticle().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/theme"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "meta")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "评论管理",response = AdminController.class)
    })
    private Object meta_view(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getArticle().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/meta"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "userlist")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "评论管理",response = AdminController.class)
    })
    private Object user_view(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getAuthor().equals(1)) {
            UserInfo user = userDAO.findUser(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/role"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @RequestMapping(value = "table")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "分类读取",response = AdminController.class)
    })
    private Object render_table(String m, @RequestParam(required = false) String p, Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getArticle().equals(1)) {
            switch (m){
                case "theme":
                    /**code here*/
                    break;
                case "article":
                    /**code here*/
                    model.addAttribute("title", "文章分类详细设置");
                    model.addAttribute("p", p);
                    return new ModelAndView("admin/table");
            }
            return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "list")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "分类读取",response = AdminController.class)
    })
    @ResponseBody
    private Object getlist(String m, @RequestParam(required = false) String p, Integer page, Integer limit, HttpSession session) {
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getArticle().equals(1)) {
            String data = "";
            int count = 0;
            switch (m) {
                case "template":
                    List<TemplatesContent> TemplateLists = templatesDAO.gettemplates((page - 1) * limit, limit);
                    if (TemplateLists != null) {
                        for (TemplatesContent temp : TemplateLists) {
                            data = data + "{\"id\":\"" + temp.getId().toString() + "\",\"name\":\"" + temp.getName() +
                                    "\",\"type\":\"" + temp.getType() + "\",\"path\":\"" + temp.getPath() + "\",\"des\":\"" + temp.getDes() + "\"},";
                        }
                        count = templatesDAO.gettemplatesnum();
                        data = "{\"code\":0,\"msg\":\"success\",\"count\":" + count + ",\"data\":[" + data.substring(0, data.length() - 1) + "]}";
                        return data;
                    } else {
                        return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
                    }
                case "theme":
                    List<ThemeList> ThemeLists = articleDAO.getThemeList();
                    if (ThemeLists != null) {
                        for (ThemeList themelist : ThemeLists) {
                            data = data + "{\"id\":\"" + count + "\",\"theme\":\"" + themelist.getPost_theme() + "\",\"num\":\"" + articleDAO.getThemeAritcleNum(themelist.getPost_theme()) + "\"},";
                            count ++;
                        }
                        count = ThemeLists.size();
                        data = "{\"code\":0,\"msg\":\"success\",\"count\":" + count + ",\"data\":[" + data.substring(0, data.length() - 1) + "]}";
                        return data;
                    } else {
                        return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
                    }
                case "article":
                    List<ArticleView> ThemeArticleLists = articleDAO.getThemeAritcle(p, (page - 1) * limit, limit);
                    if (ThemeArticleLists != null) {
                        for (ArticleView articlelist : ThemeArticleLists) {
                            data = data + "{\"id\":\"" + articlelist.getPost_id() + "\",\"post_date\":\"" + articlelist.getPost_date().substring(0, articlelist.getPost_date().indexOf(".")) +
                                    "\",\"post_theme\":\"" + articlelist.getPost_theme() + "\",\"post_title\":\"" + articlelist.getPost_title() +
                                    "\",\"post_label\":\"" + articlelist.getPost_label() + "\",\"post_status\":\"" + articlelist.getPost_status() +
                                    "\",\"is_up\":\"" + articlelist.getIs_up() + "\",\"cover_pic\":\"" + articlelist.getCover_pic() +
                                    "\",\"post_email\":\"" + articlelist.getPost_email() +
                                    "\",\"author_contact\":\"" + articlelist.getAuthor_contact() + "\"},";
                            //"\",\"post_content\":\"" + articlelist.getPost_content().replace("\n", "\\\\n") +
                        }
                        count = articleDAO.getThemeAritcleNum(p);
                        data = "{\"code\":0,\"msg\":\"success\",\"count\":" + count + ",\"data\":[" + data.substring(0, data.length() - 1) + "]}";
                        return data;
                    } else {
                        return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
                    }
                case "meta":
                    QueryWrapper query = new QueryWrapper();
                    count = commentService.list(query).size();
                    query.last("limit "+(page - 1) * limit+", "+ limit);
                    List<CommentView> commentViewList = commentService.list(query);
                    if (commentViewList != null) {
                        for (CommentView commentView : commentViewList){
                            data = data + "{\"id\":\"" + commentView.getId() + "\",\"user_id\":\"" + commentView.getUserId() +
                            "\",\"reply_to\":\"" + commentView.getReplyTo() + "\",\"post_id\":\"" + commentView.getPostId() +
                            "\",\"content\":\"" + commentView.getContent() + "\",\"create_time\":\"" + commentView.getCreateTime() +
                            "\",\"is_post\":\"" + commentView.getIsPost() + "\"},";
                        }
                        data = "{\"code\":0,\"msg\":\"success\",\"count\":" + count + ",\"data\":[" + data.substring(0, data.length() - 1) + "]}";
                        return data;
                    } else {
                        return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
                    }
                case "userlist":
                    count = userDAO.getUserListNum();
                    List<Role> roleList = userDAO.getUserList((page - 1) * limit, limit);
                    if(roleList != null){
                        for (Role roleinfo : roleList){
                            data = data + "{\"id\":\"" + roleinfo.getId() + "\",\"email\":\"" + roleinfo.getEmail() + "\",\"author\":\"" + roleinfo.getAuthor() +
                            "\",\"settings\":\"" + roleinfo.getSettings() + "\",\"article\":\"" + roleinfo.getArticle() +
                            "\",\"templates\":\"" + roleinfo.getTemplates() + "\",\"vip\":\"" + roleinfo.getVip() + "\"},";
                        }
                        data = "{\"code\":0,\"msg\":\"success\",\"count\":" + count + ",\"data\":[" + data.substring(0, data.length() - 1) + "]}";
                        return data;
                    } else {
                        return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
                    }
                default:
                    return "{\"code\":0,\"msg\":\"failure\",\"count\":\"0\",\"data\":[]}";
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @GetMapping(value = "data")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "数据库备份页面",response = AdminController.class)
    })
    private Object sql_view(Model model, HttpSession session, @RequestParam(required = false) String m){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getRole().equals(4L)) {
            if (m != null && m.equals("recover")) {
                model.addAttribute("title", "备份文件列表");
                return new ModelAndView("admin/source");
            }else {
                UserInfo user = userDAO.findUser(email);
                model.addAttribute("role", roleselect);
                model.addAttribute("userinfo", user);
                model.addAttribute("seo", urlDAO.Getoption_value(7));
                model.addAttribute("title", urlDAO.Getoption_value(2));
                return new ModelAndView("admin/backup"); // 此处指向界面
            }
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "sql")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "数据库执行页面",response = AdminController.class)
    })
    private Object sql_execute(Model model, HttpSession session){
        String email = (String) session.getAttribute("email");
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getRole().equals(4L)) {
            UserInfo user = userDAO.findUser(email);
            model.addAttribute("role", roleselect);
            model.addAttribute("userinfo", user);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            return new ModelAndView("admin/sql"); // 此处指向界面
        }else{
            return "redirect:/admin"; // 此处指向界面
        }
    }

    @GetMapping(value = "view/{id}")
    @ApiOperation(value = "GET")
    @ApiResponses(value = {
            @ApiResponse(code = 200 ,message = "文章预览页面",response = AdminController.class)
    })
    private Object article_view(Model model, HttpSession session, @PathVariable String id){
        String email = (String) session.getAttribute("email");
        int post_id = Integer.parseInt(id) == 0 ? 1 : Integer.parseInt(id);
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && roleselect.getArticle().equals(1)) {
            List<ArticleView> articleinfo = articleDAO.getoneViewArticle(post_id);
            model.addAttribute("userinfo", userDAO.findUser(email));
            model.addAttribute("email", email);
            model.addAttribute("seo", urlDAO.Getoption_value(7));
            model.addAttribute("siteurl", urlDAO.Getoption_value(1));
            model.addAttribute("title", urlDAO.Getoption_value(2));
            model.addAttribute("logo", urlDAO.Getoption_value(6));
            model.addAttribute("articlelist", articleinfo);
            model.addAttribute("morereadlist", articleDAO.getRandomArticle(4));
            return new ModelAndView("view");
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "save")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "选项存储",response = AdminController.class)
    })
    @ResponseBody
    private Object save_options(Model model, HttpSession session,
                                String m,
                                @RequestParam(required = false, defaultValue = "1") int id,
                                @RequestParam(required = false) String theme,
                                @RequestParam(required = false) String label,
                                @RequestParam(required = false) String title,
                                @RequestParam(required = false) String status,
                                @RequestParam(required = false, defaultValue = "0") int up,
                                @RequestParam(required = false) String pic,
                                @RequestParam(required = false) String editemail,
                                @RequestParam(required = false, defaultValue = "0") int settings,
                                @RequestParam(required = false, defaultValue = "0") int article,
                                @RequestParam(required = false, defaultValue = "0") int author,
                                @RequestParam(required = false, defaultValue = "0") int templates,
                                @RequestParam(required = false, defaultValue = "0") int vip){
        String email = (String) session.getAttribute("email");
        int post_id = id == 0 ? 1 : id;
        Role roleselect = userDAO.Roleset(email);
        if(checkAdmin(session) && (roleselect.getArticle().equals(1) || roleselect.getAuthor().equals(1))) {
            switch (m){
                case "article":
                    if(status.equals("reject")) {
                        articleDAO.SendArticleMsg(post_id, "你的文章["+title+"]未通过小编审核");
                        articleDAO.RejectArticle(post_id, status);
                        return new Status(200, 39, "驳回稿件成功！");
                    }else {
                        if(status.equals("publish")){
                            articleDAO.SendArticleMsg(post_id, "你的文章["+title+"]已发布");
                        }
                        articleDAO.UpdateArticle(post_id, theme, title, label, status, up, pic);
                        return new Status(200, 39, "修改稿件成功");
                    }
                case "role":
                    long role = checkRole(settings, article, author, templates);
                    userDAO.updateUserRole(id, editemail, role, settings, article, author, templates, vip);
                    userDAO.updateUserAccount(id, editemail);
                    return new Status(200, 40, "修改权限成功");
                default:
                    return new Status(500, 21, "参数异常");
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }
}
