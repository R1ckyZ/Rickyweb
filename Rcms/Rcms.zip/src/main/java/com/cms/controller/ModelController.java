package com.cms.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cms.model.bean.*;
import com.cms.model.dao.ArticleDAO;
import com.cms.model.dao.TemplatesDAO;
import com.cms.model.dao.UrlDAO;
import com.cms.model.dao.UserDAO;
import com.cms.service.CommentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.system.ApplicationHome;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
@Api(tags = "ModelController")
public class ModelController extends CheckController{

    @Autowired
    private UserDAO userDAO;
    @Autowired
    private UrlDAO urlDAO;
    @Autowired
    private TemplatesDAO templatesDAO;
    @Autowired
    private ArticleDAO articleDAO;
    @Autowired
    CommentService commentService;
    @Value("${file.uploadFolder}")
    private String realBasePath;
    @Value("${file.accessPath}")
    private String accessPath;

    private final Logger logger = LoggerFactory.getLogger(getClass());

    private String ReadFile(FileInputStream filename) throws IOException {
        try (InputStream is = new BufferedInputStream(filename);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()){
            byte[] flush = new byte[1024];
            int length;
            while((length = is.read(flush)) != -1){
                baos.write(flush, 0, length);
            }
            baos.flush();
            return new String(baos.toByteArray());
        }
    }

    private void WriteFile(File filename, byte[] context) throws IOException {
        try (InputStream is = new ByteArrayInputStream(context);
             OutputStream os = new BufferedOutputStream(new FileOutputStream(filename, false));) {
            // 操作（分段读取）
            byte[] flush = new byte[1024];// 缓冲容器
            int length;// 接收长度
            while ((length = is.read(flush)) != -1) {
                os.write(flush, 0, length);
            }
            os.flush();
        }
    }

    private void getList(CommentView comment){
        QueryWrapper query = new QueryWrapper();
        query.eq("parent_id",comment.getId());

        List<CommentView> comments = commentService.list(query);

        // 判断comments是否为空
        if(comments.size() > 0 ){
            comment.setCommentList(comments);
            for (int i = 0; i < comments.size(); i++) {
                // 递归查询下层
                getList(comments.get(i));
            }
        }
    }

    @PostMapping(value = "upload")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "上传成功",response = ModelController.class)
    })
    @ResponseBody
    public Object upload(@RequestParam(required = false) String guid, MultipartFile file, HttpSession session, HttpServletRequest request){
        if(checkUser(session)) {
            if (file.isEmpty()) {
                return new Status(200, 3, "请选择上传文件！");
            }
            // 数据库动态 ext
            final String extreg = ".+(" + urlDAO.Getoption_value(5).getOption_value() + ")$";
            String fileName = file.getOriginalFilename();
            if (fileName != null) {
                // System.out.println(filename);
                Pattern pattern = Pattern.compile(extreg);
                Matcher matcher = pattern.matcher(fileName.toLowerCase());
                String fileext = ".temp";
                if (matcher.find()) {
                    fileext = fileName.substring(fileName.lastIndexOf(".")).toLowerCase();
                    fileName = DigestUtils.md5DigestAsHex(UUID.randomUUID().toString().replace("-", "").getBytes()).substring(0, 16) + fileext;
                } else {
                    return new Status(200, 4, "上传文件格式错误！");
                }

                try {
                    java.util.Date todayDate = new java.util.Date();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    String today = dateFormat.format(todayDate);
                    // 域名访问的相对路径（通过浏览器访问的链接-虚拟路径）
                    String saveToPath = accessPath + today + "/";
                    // 真实路径，实际储存的路径
                    String realPath = realBasePath + today + "/";
                    // 储存文件的物理路径，使用本地路径储存
                    logger.info("上传图片名为：" + fileName+"--虚拟文件路径为：" + saveToPath +"--物理文件路径为：" + realPath);
                    // 判断有没有对应的文件夹
                    File destFile = new File(realPath);
                    if (!destFile.getParentFile().exists()) {
                        destFile.getParentFile().mkdirs();
                    }
                    if(guid != null){
                        fileName = DigestUtils.md5DigestAsHex((UUID.randomUUID().toString().replace("-", "")+guid).getBytes()).substring(0, 16) + fileext;
                        File dest = new File(destFile, fileName);
                        FileUtils.copyInputStreamToFile(file.getInputStream(), dest);
                        String imgUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() +saveToPath+fileName;
                        return new Status(200, 6, imgUrl);
                    } else {
                        File dest = new File(destFile, fileName);
                        FileUtils.copyInputStreamToFile(file.getInputStream(), dest);
                        return new Status(200, 6, "上传成功！文件存储在 "+saveToPath+fileName);
                    }
                } catch (Exception e) {
                    logger.error(String.valueOf(e));
                    return new Status(500, 5, "上传失败！");
                }
            } else {
                return new Status(200, 3, "请选择上传文件！");
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "contents")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "读取成功",response = ModelController.class)
    })
    @ResponseBody
    private Object file_get_contents(String file, String type, HttpSession session) {
        if(checkUser(session)) {
            String fileext = file.substring(file.lastIndexOf(".")+1).toLowerCase();
            // 待改进: 正则过滤, 分区指定目录
            if(fileext.equals(type)) {
                try {
                    ApplicationHome home = new ApplicationHome(getClass());
                    File jarFile = home.getSource();
                    String PATH = jarFile.getParentFile().getPath();
                    file = PATH + "/resources" + file;
                    FileInputStream readfile = new FileInputStream(file);
                    String content = ReadFile(readfile);
                    return new Status(200, 11, content);
                } catch (Exception e) {
                    throw new MyException(500, "文件读取失败！");
                }
            }else{
                throw new MyException(500, "文件格式不匹配！");
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "downloads")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "下载成功",response = ModelController.class)
    })
    private void file_download(String path, HttpSession session, HttpServletResponse response) {
        if(checkUser(session)) {
                try {
                    ApplicationHome home = new ApplicationHome(getClass());
                    File jarFile = home.getSource();
                    String PATH = jarFile.getParentFile().getPath();
                    String filepath = PATH + "/resources" +path;
                    BufferedInputStream br = new BufferedInputStream(new FileInputStream(filepath));
                    byte[] buf = new byte[1024];
                    int len = 0;
                    response.reset(); // 非常重要
                    response.setContentType("application/x-msdownload");
                    response.setHeader("Content-Disposition", "attachment; filename=" + path);
                    OutputStream out = response.getOutputStream();
                    while ((len = br.read(buf)) > 0)
                        out.write(buf, 0, len);
                    br.close();
                    out.close();
                } catch (Exception e) {
                    throw new MyException(500, "文件下载失败！");
                }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "delete")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "删除成功",response = ModelController.class)
    })
    @ResponseBody
    private Object file_delete(String m, @RequestParam(required = false) String filepath,
                               @RequestParam(required = false) String type,
                               @RequestParam(required = false) int id,
                               @RequestParam(required = false) String email,
                                           HttpSession session){
        if(checkUser(session)) {
            switch (m) {
                case "template":
                    try {
                        ApplicationHome home = new ApplicationHome(getClass());
                        File jarFile = home.getSource();
                        String PATH = jarFile.getParentFile().getPath();
                        File filterpath = new File(filepath.replace("\\", "/"));
                        String deletepath = PATH + filterpath.getCanonicalPath();
                        File deletefile = new File(deletepath);
                        if (templatesDAO.FindTemplates(filepath, type).equals(1) && deletefile.delete()) {
                            templatesDAO.DelTemplates(filepath, type);
                            return new Status(200, 14, "文件删除成功！");
                        } else {
                            return new Status(200, 16, "文件不存在！");
                        }
                    } catch (Exception e) {
                        return new Status(500, 15, "文件删除失败！");
                    }
                case "article":
                    int post_id = id == 0 ? 1 : id;
                    articleDAO.DeleteArticle(post_id);
                    return new Status(200, 40, "稿件删除成功！");
                case "role":
                    userDAO.DeleteUser(id, email);
                    userDAO.DeleteUserInfo(id);
                    return new Status(200, 41, "用户注销成功！");
                default:
                    throw new MyException(500, "服务异常！");
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @PostMapping(value = "write")
    @ApiOperation(value = "POST")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "写入成功",response = ModelController.class)
    })
    @ResponseBody
    private Object file_write(String name, String filepath, String type, String des, String content, HttpSession session){
        if(checkUser(session)) {
            String templatepath;
            if(templatesDAO.FindTemplates("/templates/"+filepath, type).equals(0)) {
                // 待改进: 正则过滤, 分区指定目录
                try {
                    ApplicationHome home = new ApplicationHome(getClass());
                    File jarFile = home.getSource();
                    String PATH = jarFile.getParentFile().getPath();
                    templatepath = PATH + "/resources/templates/" + filepath;
                    File file = new File(templatepath);
                    templatesDAO.AddTemplates(name, "/templates/" + filepath, type, des);
                    WriteFile(file, content.getBytes());
                    return new Status(200, 12, "新建模板成功！");
                } catch (Exception e) {
                    return new Status(500, 13, "新建模板失败！");
                }
            }else{
                try{
                    ApplicationHome home = new ApplicationHome(getClass());
                    File jarFile = home.getSource();
                    String PATH = jarFile.getParentFile().getPath();
                    templatepath = PATH + "/resources/templates/" + filepath;
                    File file = new File(templatepath);
                    WriteFile(file, content.getBytes());
                    return new Status(200, 12, "模板覆盖成功！");
                } catch (Exception e) {
                    return new Status(500, 13, "模板覆盖失败！");
                }
            }
        }else{
            throw new MyException(401, "您没有权限访问此接口！");
        }
    }

    @RequestMapping(value = "read/{year}/{month}/{day}/{id}")
    @ApiOperation(value = "文章阅读")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "浏览页",response = IndexController.class)
    })
    public Object article_read(Model model, HttpSession session, @PathVariable String year, @PathVariable String month, @PathVariable String day, @PathVariable String id){
        String email = (String) session.getAttribute("email");
        int post_id = Integer.parseInt(id) == 0 ? 1 : Integer.parseInt(id);
        List<ArticleView> articleinfo = articleDAO.getoneArticle(post_id);
        if(articleinfo.size() == 0){
            return "redirect:/";
        }
        session.setAttribute("post_id", post_id);
        List<Date> dateList = new ArrayList<>();
        dateList.add(new Date(year, month, day));
        articleDAO.AddReadTime(post_id);

        QueryWrapper query = new QueryWrapper();
        query.eq("parent_id", 0);
        query.eq("post_id", id);

        List<CommentView> list = commentService.list(query);
        // 第一层
        if(list.size() > 0 ){
            for (int i = 0; i < list.size(); i++) {
                // 递归查询下层
                getList(list.get(i));
            }
        }

        if(session.getAttribute("userid") != null){
            int user_id = (int) session.getAttribute("userid");
            List<MsgInfo> msginfo = articleDAO.getMsgInfo(user_id);
            int msgcount = msginfo.size();
            model.addAttribute("msginfo", msginfo);
            model.addAttribute("msgcount", msgcount);
        }

        model.addAttribute("clist",list);
        model.addAttribute("userinfo", userDAO.findUser(email));
        model.addAttribute("email", email);
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        model.addAttribute("siteurl", urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("logo", urlDAO.Getoption_value(6));
        model.addAttribute("dateList", dateList);
        model.addAttribute("articlelist", articleinfo);
        model.addAttribute("morereadlist", articleDAO.getRandomArticle(4));
        return new ModelAndView("read");
    }

    @RequestMapping(value = "theme/{theme}")
    @ApiOperation(value = "文章主题筛选")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "主题优先",response = IndexController.class)
    })
    public Object theme_first(Model model, HttpSession session, @PathVariable String theme){
        String email = (String) session.getAttribute("email");
        session.setAttribute("more", 1);
        session.setAttribute("theme", theme);
        List<ArticleView> articleDAOList = articleDAO.getArticlefilterbytheme(theme, 0, 6);
        model.addAttribute("userinfo", userDAO.findUser(email));
        model.addAttribute("email", email);
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        model.addAttribute("siteurl", urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("logo", urlDAO.Getoption_value(6));
        model.addAttribute("articlelist", articleDAOList);
        return new ModelAndView("index"); // 此处指向界面
    }

    @RequestMapping(value = "search/{things}")
    @ApiOperation(value = "搜索结果筛选")
    @ApiResponses(value = {
            @ApiResponse( code = 200 ,message = "搜索优先",response = IndexController.class)
    })
    public Object search_first(Model model, HttpSession session, @PathVariable String things){
        String email = (String) session.getAttribute("email");
        session.setAttribute("more", 1);
        session.setAttribute("search", things);
        List<ArticleView> articleDAOList = articleDAO.getArticlefilterbysearch(things, 0, 6);
        int articlecount = articleDAOList.size();
        model.addAttribute("userinfo", userDAO.findUser(email));
        model.addAttribute("email", email);
        model.addAttribute("seo", urlDAO.Getoption_value(7));
        model.addAttribute("siteurl", urlDAO.Getoption_value(1));
        model.addAttribute("title", urlDAO.Getoption_value(2));
        model.addAttribute("logo", urlDAO.Getoption_value(6));
        model.addAttribute("articlelist", articleDAOList);
        model.addAttribute("search", 1);
        model.addAttribute("articlecount", articlecount);
        return "index::table_refresh";
    }
}
