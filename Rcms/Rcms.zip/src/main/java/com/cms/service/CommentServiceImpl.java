package com.cms.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cms.model.bean.CommentView;
import com.cms.model.dao.CommentDAO;
import org.springframework.stereotype.Service;

@Service
public class CommentServiceImpl extends ServiceImpl<CommentDAO, CommentView> implements CommentService {
}
