package com.cms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cms.model.bean.CommentView;

public interface CommentService extends IService<CommentView> {
}
