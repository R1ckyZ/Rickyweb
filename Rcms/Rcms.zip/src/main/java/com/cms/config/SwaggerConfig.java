package com.cms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.TagsSorter;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * @author Ricky 测试用，正式上线请注释
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {
    /*RequestHandlerSelectors有几种扫描方式：
      1.basePackage：指定包扫描
        示例：.apis(RequestHandlerSelectors.basePackage("com.example.swagger.controller"))
      2.any:扫描该项目的所有请求链接
        示例：.apis(RequestHandlerSelectors.any())
      3.none：所有请求链接都不扫描
        示例：.apis(RequestHandlerSelectors.none())
       4.withClassAnnotation:通过类的注解扫描,就是类名上面的注释
        可以是Controller，RestController,RequestMapping,GetMapping ,PostMapping等等
        示例：.apis(withClassAnnotation.)
       5.withMethodAnnotation:通过方法的注解扫描，也就是方法上面的注解
        可以是RequestMapping ,GetMapping ,PostMapping等等
        示例：.apis(RequestHandlerSelectors.withMethodAnnotation(RequestMapping.class))
        一般推荐第一种，其他作为了解即可
     */
    @Bean
    public Docket apiDocket() {
        return new Docket(DocumentationType.SWAGGER_2)
            .apiInfo(apiInfo())
            .select()
            .apis(RequestHandlerSelectors.basePackage("com.cms.controller"))
            .paths(PathSelectors.any())
            .build();
    }

    @Bean
    public UiConfiguration uiConfiguration() {
        return UiConfigurationBuilder.builder()
            .deepLinking(true)
            .defaultModelExpandDepth(1)
            .validatorUrl("")
            .displayOperationId(true)
            .displayRequestDuration(true)
            .tagsSorter(TagsSorter.of("release"))
            .showExtensions(true)
            .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
            .title("Rcms管理平台")
            .description("Ricky CMS")
            .termsOfServiceUrl("https://github.com/Ricky-369369/Rickyweb")
            .version("1.0")
            .build();
    }
}